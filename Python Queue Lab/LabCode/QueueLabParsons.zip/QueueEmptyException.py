class QueueEmptyException(Exception):
    pass
