class QueueFullException(Exception):
    pass
