class StackFullException(Exception):
    pass
