class StackEmptyException(Exception):
    pass
